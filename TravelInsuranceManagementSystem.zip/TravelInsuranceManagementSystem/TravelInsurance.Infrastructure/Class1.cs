﻿namespace TravelInsurance.Infrastructure
{
    public class Class1
    {

    }
}
