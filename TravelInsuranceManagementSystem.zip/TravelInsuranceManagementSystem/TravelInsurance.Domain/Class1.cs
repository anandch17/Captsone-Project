﻿namespace TravelInsurance.Domain
{
    public class Class1
    {

    }
}
