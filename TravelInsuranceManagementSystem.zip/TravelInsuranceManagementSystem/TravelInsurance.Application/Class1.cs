﻿namespace TravelInsurance.Application
{
    public class Class1
    {

    }
}
